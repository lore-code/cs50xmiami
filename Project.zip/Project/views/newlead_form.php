
<form action="newlead.php" method="post">
    <div class="form-style-10">
        <align= "left" ></align>
        <width = "1200px" ></width>
<h1>Add New Client<span>If no application id use phone number.</span></h1>
<form>
    <div class="section"><span>1</span>Primary Info</div>
    <div class="inner-wrap">
        <label>Name <input type="text" name="name" placeholder= "Name" /></label> 
        <label>Phone <input type="text" name="phone" maxlength="10"placeholder= "Phone"  /></label>
        <label>Email <input type="email" name="email" placeholder= "Email"  /></label>
        <label>Date of Birth<input type="mm" name="mm" value="" maxlength="2" placeholder= "MM" />-<input type="dd" name="dd" value="" maxlength="2" placeholder= "DD"  />-<input type="yyyy"  name="yyyy" maxlength="4"  placeholder= "YYYY" /></label>
        <label>Age <input type="text" name="age"placeholder= "Age" disabled /></label>
        <label>Social<input type="text" name="social"  maxlength="9" placeholder= "  --  --    "  /></label>
        <label>Address <input type="text" name="address" placeholder= "Address"  /></label>
        <label>City <input type="text" name="city" placeholder= "City"   /></label>
        <label>State <input type="text" name="state" maxlength="2" placeholder= "State"  /></label>
        <label>Zip <input type="text" name="zip"placeholder= "Zip Code"  maxlength="5"/></label>
        <label>Application Id <input type="text" name="id"placeholder= "Application Id"    maxlength="10" /></label>
        
    </div>

   
    
    <div class="section"><span>2</span>Income and Premium Info</div>
    <div class="inner-wrap">
        <label>Primary Employer <input type="text" name="priempl" placeholder= "Employer Name"   /></label> 
        <label>Primary Income <input type="text" name="priinc" placeholder= "Annual Income"   /></label>
        <label>Client Premium <input type="text" name="clientprem" placeholder= "Client Premium"  /></label> 
        <label>Subsidy <input type="text" name="subsidy" placeholder= "Subsidy"   /></label>
        
     </div>  
        <div class="section"><span>3</span>Followup Info</div>
    <div class="inner-wrap">
        <label>Followup <input type="text" name="followup" placeholder= "Followup"  /></label>
        <label>Time <input type="text" name="time" placeholder= "Time"  /></label>
        </br>
        <label>Comments <input type="text" name="comments"placeholder= "Comments"  /></label>
        
    </div>
    <div class="button-section">
      <input type="submit" name="submit" value="Add Client" />

    </div>
</form>
</div>