	<div class="floating-fu"><H3> <?php echo $bdays  ?> <?php echo $monthName ?> (<?php echo $counterbdays ?>)</H3>
	<table class = "table table-striped">
	<tr>
		<th class="text-center">Name</th>
		<th class="text-center">Phone</th>
		<th class="text-center">Sent Bday Greeting</th>
	</tr>

	<?php foreach ($birthdays as $birthday): ?>
	
		<tr>
			<td><?= $birthday["name"] ?></td>
			<td><?= $birthday["phone"] ?></td>
	<td><form action="birthday.php" method="post">
             <input type="hidden"  name="id" value="<?=$birthday["id"]?>">
            <button type="submit"  name="sent" value="SENT" class="btn btn-default">SENT</button>
	</form></td>
		</tr>
		<br>
	<?php endforeach ?>
	

</table>
</div>