<h1><?php echo "There are " . $d2 ." days until ACA enrollment!" ?></h1>
<h1><?php echo "There are " . $d4 ." days until AEP enrollment!" ?></h1>



	<div class="floating-fu"><H3> <?php echo $title ?> (<?php echo $counter ?>)</H3>
	<table class = "table table-striped">
	<tr>
		<th class="text-center">Name</th>
		<th class="text-center">Phone</th>
		<th class="text-center">City</th>
		<th class="text-center">Comments</th>
		<th class="text-center">Edit</th>
		<th class="text-center">View</th>
	</tr>

	<?php foreach ($transactions as $transaction): ?>
		<tr>
			<td><?= $transaction["name"] ?></td>
			<td><?= $transaction["phone"] ?></td> 
			<td><?= $transaction["city"] ?></td> 
			<td><?= $transaction["comments"] ?></td>
			<td><form action="edit.php" method="post">
             <input type="hidden"  name="id" value="<?=$transaction["id"]?>">
            <button type="submit"  name="edit" value="Edit" class="btn btn-default">EDIT</button>
	</form></td>
		</form></td>
			<td><form action="view.php" method="post">
             <input type="hidden"  name="id" value="<?=$transaction["id"]?>">
            <button type="submit"  name="view" value="view" class="btn btn-default">VIEW</button>
	</form></td>
		</tr>
		<br>
	<?php endforeach ?>

</table>
</div>

