

<form action="view_form.php" method="post">
    <div class="form-style-10">
        <align= "left" ></align>
        <width = "1200px" ></width>
<h1>File for <?php echo $lead["name"] ?> </h1>
<form>
    <div class="section"><span>1</span>Primary Info</div>
    <div class="inner-wrap-view">
        <label>Name  <?php echo $lead["name"] ?>  </label> &nbsp;&nbsp;&nbsp;&nbsp;
            <label>Phone  <?php echo $lead["phone"] ?>   </label> &nbsp;&nbsp;&nbsp;&nbsp;
        <label>Email <?php echo $lead["email"] ?> </label> &nbsp;&nbsp;&nbsp;&nbsp;
<label>Date of Birth <?php echo $lead["mm"] ?>- <?php echo $lead["dd"] ?>  -  <?php echo $lead["yyyy"] ?></label>&nbsp;&nbsp;&nbsp;&nbsp;
        <label>Age <?php echo $lead["age"] ?> </label> &nbsp;&nbsp;&nbsp;&nbsp;
        <label>Social  <?php echo $lead["social"] ?></label> &nbsp;&nbsp;&nbsp;&nbsp;
        <label>Address <?php echo $lead["address"] ?></label> &nbsp;&nbsp;&nbsp;&nbsp;
        <label>City <?php echo $lead["city"] ?></label>  &nbsp;&nbsp;&nbsp;&nbsp;
        <label>State <?php echo $lead["state"] ?></label>&nbsp;&nbsp;&nbsp;&nbsp;
        <label>Zip <?php echo $lead["zip"] ?></label>&nbsp;&nbsp;&nbsp;&nbsp;
        <label>Application Id <?php echo $lead["id"] ?></label>&nbsp;&nbsp;&nbsp;&nbsp;
    </div>

    
    <div class="section"><span>2</span>Income Info</div>
        <div class="inner-wrap-view">
        <label>Primary Employer <?php echo $income["priempl"] ?></label> &nbsp;&nbsp;&nbsp;&nbsp;
        <label>Primary Income <?php echo $income["priinc"] ?></label>&nbsp;&nbsp;&nbsp;&nbsp;
         <label>Client Premium <?php echo $income["clientprem"] ?></label>&nbsp;&nbsp;&nbsp;&nbsp;
        <label>Subsidy <?php echo $income["subsidy"] ?></label>&nbsp;&nbsp;&nbsp;&nbsp;
        </div>
        
        <div class="section"><span>3</span>Followup Info</div>
        <div class="inner-wrap-view">
        <label>Followup <?php echo $lead["followup"] ?></label>&nbsp;&nbsp;&nbsp;&nbsp;
        <label>Time <?php echo $lead["time"] ?></label><br/>&nbsp;&nbsp;&nbsp;&nbsp;
       <label>Comments <?php echo $lead["comments"] ?></label>&nbsp;&nbsp;&nbsp;&nbsp;
        
    </div>
    <div class="button-section">
      <input type="button" value="Print or Save" button onclick="myFunction()">

<script>
function myFunction() {
    window.print();
}
</script>

    </div>
</form>
</div>



             
    


             
    
