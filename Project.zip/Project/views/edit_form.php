

<form action="edits.php" method="post">
    <div class="form-style-10">
        <align= "left" ></align>
        <width = "1200px" ></width>
<h1>Update <?php echo $lead["name"] ?><span>Make changes as needed!</span></h1>
<form>
    <div class="section"><span>1</span>Primary Info</div>
    <div class="inner-wrap">
        <label>Name <input type="text" name="name" value ="<?php echo $lead["name"] ?>" placeholder= "Name"  /></label> 
        <label>Phone <input type="text" name="phone"value ="<?php echo $lead["phone"] ?>" placeholder= "Phone" maxlength="10"   /></label>
        <label>Email <input type="email" name="email" value ="<?php echo $lead["email"] ?>" placeholder= "Email"  /></label>
<label>Date of Birth<input type="mm" name="mm" value ="<?php echo $lead["mm"] ?>" maxlength="2" placeholder= "MM"  />-<input type="dd"placeholder= "DD"  name="dd" value ="<?php echo $lead["dd"] ?>" maxlength="2"  />-<input type="yyyy" placeholder= "YYYY"  name="yyyy" maxlength="4"  value ="<?php echo $lead["yyyy"] ?>"/></label>
        <label>Age <input type="text" name="age" value ="<?php echo $lead["age"] ?>"maxlength ="2" placeholder= "Age"  /></label>
        <label>Social<input type="text" name="social" value ="<?php echo $lead["social"] ?>"  maxlength="9" placeholder= "xx-xx-xxxx"  /></label>
        <label>Address <input type="text" name="address" value ="<?php echo $lead["address"] ?>" placeholder= "Address"  /></label>
        <label>City <input type="text" name="city" value ="<?php echo $lead["city"] ?>" placeholder= "City"   /></label> 
        <label>State <input type="text" name="state" value ="<?php echo $lead["state"] ?>" maxlength="2" placeholder= "State"  /></label>
        <label>Zip <input type="text" name="zip" value ="<?php echo $lead["zip"] ?>" placeholder= "Zip Code" maxlength="2"  /></label>
        <label>Application Id <input type="text" name="id"value ="<?php echo $lead["id"] ?>" placeholder= "Application Id" maxlength="10" /></label>
    </div>

    
    
    
    <div class="section"><span>2</span>Income Info</div>
        <div class="inner-wrap">
        <label>Primary Employer <input type="text" name="priempl"  value ="<?php echo $income["priempl"] ?>"placeholder= "Employer"  /></label> 
        <label>Primary Income <input type="text" name="priinc"value ="<?php echo $income["priinc"] ?>" placeholder= "$"    /></label>
         <label>Client Premium <input type="text" name="clientprem" value ="<?php echo $income["clientprem"] ?>" placeholder= "$"  /></label>
        <label>Subsidy <input type="text" name="subsidy"value ="<?php echo $income["subsidy"] ?>" placeholder= "$"  /></label>
        <div class="section"><span>3</span>Followup Info</div>
        <div class="inner-wrap">
        <label>Followup <input type="text" name="followup"value ="<?php echo $lead["followup"] ?>" placeholder= "Yes or No" maxlength="3" /></label>
        <label>Time <input type="text" name="time"value ="<?php echo $lead["time"] ?>" placeholder= "AM or PM" maxlength="2"  /></label><br/>
       <label>Comments <input type="text" name="comments" value="<?php echo $lead["comments"] ?>" placeholder= "Comments" /></label>
        
    </div>
    <div class="button-section">
      <input type="submit" name="submit" value="Update Client" />

    </div>
</form>
</div>



             
    


             
    
