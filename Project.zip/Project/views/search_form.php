<form action="results.php" method="post">
    <img alt="Search" width="42" height="42"align="middle" src="/img/search.png"/><H3><?php echo "$title" ?></H3>
    <fieldset>
        <div class="form-group">
            <h4>Please search by one item at a time.</h4>
            <input autofocus class="form-control" name="phone" placeholder="Phone" maxlength="10" type="text"/>
            <input class="form-control" name="name" placeholder="Name" type="text"/>
         
            
        <div class="form-group">
            <button type="submit" class="btn btn-default">Search</button>
        </div>
    </fieldset> 
</form>