
	<div class="floating-box"><H3> <?php echo $title ?> (<?php echo $counter ?>)</H3>
<table class = "table table-striped">	
	<tr>
		<th class="text-center">Name</th>
		<th class="text-center">Phone</th>
		<th class="text-center">City</th>
		<th class="text-center">Time</th>
		<th class="text-center">Comments</th>
		<th class= "text-center">Edit</th>
	</tr>

	<?php foreach ($results as $result): ?>
		<tr>
			
			<td><?= $result["name"] ?></td>
			<td><?= $result["phone"] ?></td> 
			<td><?= $result["city"] ?></td> 
			<td><?= $result["time"] ?></td> 
			<td><?= $result["comments"] ?></td>
			<td><form action="edit.php" method="post">
             <input type="hidden"  name="id" value="<?=$result["id"]?>">
            <button type="submit"  name="edit" value="Edit" class="btn btn-default">EDIT</button> 
	</form></td>
			
		</tr>
		<br>
	<?php endforeach ?>

</table>

</div>