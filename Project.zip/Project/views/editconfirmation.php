          
<form action="editconfirmation.php" method="post">
    <div class="form-style-10">
        <align= "left" ></align>
        <width = "1200px" ></width>
<h1>Confirmation!<span>Your changes were made successfully</span></h1>
<?php
 
$edits= CS50::query("SELECT * FROM edits_made WHERE id=?", $_POST["id"]);
foreach ($edits as $edit)
$date = $edit["date_time"];
?>
  
<form>

<h2>Client Information Changed</h2>
<h2> Name: <?php echo $_POST["name"] ?></h2>
<h2> Phone: <?php echo $_POST["phone"] ?></h2>
<h2> Edits were made on: <?php echo $date ?> </h2>

</form>

</div>




             
    
