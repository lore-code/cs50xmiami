<?php

    // configuration
    require("../includes/config.php"); 
    $d1=strtotime("November 01");
    $d2=ceil(($d1-time())/60/60/24); 
    
    $d3=strtotime("October 01");
    $d4=ceil(($d3-time())/60/60/24);

    $transactions = CS50::query("SELECT * FROM clients  WHERE followup ='Yes'");
    $counter = count($transactions);
    
    

    render("portfolio.php", ["transactions" => $transactions, "counter"=>$counter, "d2"=>$d2,"d4"=>$d4, 
     "title" => "Leads to Follow Up On"]);

?>
