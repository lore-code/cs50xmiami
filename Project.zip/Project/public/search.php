<?php
 
    // configuration
    require("../includes/config.php"); 
    

  

            render("search_form.php", ["title" => "Search"]);
            
    



?>




    