<?php

    // configuration
    require("../includes/config.php"); 

    // if user reached page via GET (as by clicking a link or via redirect)
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // else render form
        render("edit_form.php", ["title" => "Update Client"]);
    }

    // else if user reached page via POST (as by submitting a form via POST)
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        
         
        if(empty($_POST["name"]) || empty($_POST["phone"]) || empty($_POST["email"]) ||empty ($_POST["address"]) || empty("mm")||empty("dd")||empty("yyyy")){
            
            if(empty($_POST["name"]))
            {
                apologize("Please enter a name");
            }
            
             if(empty($_POST["phone"]))
            {
                apologize("Please enter a phone");
            }
            
             if(empty($_POST["email"]))
            {
                apologize("Please enter a name");
            }
            
             if(empty($_POST["address"]))
            {
                apologize("Please enter a address");
            }
            
             if(empty($_POST["mm"]))
            {
                apologize("Please enter a month");
            }
             if(empty($_POST["dd"]))
            {
                apologize("Please enter a day");
            }
            
             if(empty($_POST["yyyy"]))
            {
                apologize("Please enter a yyyy");
            }
            
        }
        
        if($_POST["mm"] > 12 || $_POST["mm"] <1)
        {
            apologize("Please enter a month between 1 and 12.");
        }
        
         if($_POST["dd"] > 31 || $_POST["mm"] <1)
        {
            apologize("Please enter a month between 1 and 31.");
        }
         if($_POST["yyyy"] > 2016 || $_POST["yyyy"] <1935)
        {
            apologize("Please enter a year between 1935 and 2016");
        }
        
       
         date_default_timezone_set("America/New_York"); 
        CS50::query("UPDATE clients SET name=?, phone=?, address=?, city=?, state=?, zip=?,mm=?, dd=?,yyyy=?, dob=?, age=?, followup=?, time=?, social=?,email=? WHERE id=?", $_POST["name"], $_POST["phone"], $_POST["address"], $_POST["city"], $_POST["state"], $_POST["zip"], $_POST["mm"],$_POST["dd"], $_POST["yyyy"], $_POST["mm"]."-". $_POST['dd']."-".$_POST['yyyy'], $_POST["age"], $_POST["followup"], $_POST["time"], $_POST["social"], $_POST["email"], $_POST["id"]);
        CS50::query("UPDATE income SET priempl=?, priinc=?,  clientprem=?, subsidy=?, totalprem=? WHERE id =?", $_POST["priempl"], $_POST["priinc"],  $_POST["clientprem"], $_POST["subsidy"], $_POST["clientprem"] + $_POST["subsidy"], $_POST["id"]);
        CS50::query("INSERT INTO edits_made (id, date_time) VALUES(?,?)", $_POST["id"], date('m-d-Y'));
        CS50::query("UPDATE birthdays SET name=?, month=? WHERE id=?", $_POST["name"], $_POST["mm"], $_POST["id"]);
        
      
     
    }
    
    render("editconfirmation.php");
  
?>  