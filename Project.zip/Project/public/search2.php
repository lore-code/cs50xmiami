<?php

 // if user reached page via GET (as by clicking a link or via redirect)
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // else render form
        render("search_form.php", ["title" => "Edit"]);
    }

    // else if user reached page via POST (as by submitting a form via POST)
    else if ($_SERVER["REQUEST_METHOD"] == "POST"){
   
    
    $leads= CS50::query("SELECT * FROM clients WHERE name=?", $_POST["name"]);
    
    render("results.php", ["leads" => $leads, "title" => "Results"]);
    
    }
    
    
    
  
  
  
?>  