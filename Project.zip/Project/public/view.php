<?php

    // configuration
    require("../includes/config.php"); 

    // if user reached page via GET (as by clicking a link or via redirect)
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // else render form
        render("history_form.php", ["title" => "All My Leads"]);
    }

    // else if user reached page via POST (as by submitting a form via POST)
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        
    $leads=CS50::query("SELECT * FROM clients WHERE id =?", $_POST["id"]);
    $incomes = CS50::query("SELECT * FROM income WHERE id=?", $_POST["id"]);
   
    
    
    foreach ($leads as $lead)
    $id = $lead["id"];
    $name = $lead["name"]; 
    $phone = $lead["phone"]; 
    $address = $lead["address"]; 
    $city = $lead["city"]; 
    $state = $lead["state"]; 
    $zip = $lead["zip"]; 
    $followup = $lead["followup"]; 
    $time = $lead["time"]; 
    $mm = $lead["mm"];
    $dd= $lead["dd"];
    $yyyy = $lead["yyyy"];
    $age = $lead["age"];
    $email = $lead["email"];
    $social = $lead["social"];
    $comments = $lead["comments"];
    
    foreach($incomes as $income)
    $priempl = $income["priempl"];
    $priinc = $income["priinc"];
    $clientprem = $income["clientprem"];
    $subsidy = $income["subsidy"];
    $totalprem = $income["totalprem"];
    
    
  
    render("view_form.php",["lead" => $lead, "income"=>$income]); 
    }
    
?>