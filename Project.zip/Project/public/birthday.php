<?php

    // configuration
    require("../includes/config.php"); 

    // if user reached page via GET (as by clicking a link or via redirect)
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // else render form
        render("birthdays.php", ["title" => "Birthdays"]);
    }

    // else if user reached page via POST (as by submitting a form via POST)
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        
    CS50::query ("UPDATE birthdays SET sent=?, timestamp =?  WHERE id =?", $_POST["sent"], date('m-d-Y'), $_POST["id"]); 
    
    
    }
    
     redirect("index.php");
    
?>