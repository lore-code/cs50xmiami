<?php

    // configuration
    require("../includes/config.php"); 

    $transactions = CS50::query("SELECT * FROM clients");
    $counter = count($transactions);

    render("history_form.php", ["transactions" => $transactions, "counter"=>$counter, "title" => "All my leads"]);

?>