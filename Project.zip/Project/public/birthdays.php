<?php

require("../includes/config.php");

    
$birthdays = CS50::query("SELECT * FROM birthdays WHERE month=? && sent= 'NO'", date('m'));

    $counterbdays = count($birthdays);
    
    $month = date('m');
    $monthName = date('F', mktime(0, 0, 0, $month, 10)); 
    
render("birthdays.php", ["birthdays" =>$birthdays, "counterbdays" => $counterbdays, "monthName"=>$monthName, "bdays"=>"Birthdays for month of "]);
?>