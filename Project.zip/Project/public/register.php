<?php

    // configuration
    require("../includes/config.php");

    // if user reached page via GET (as by clicking a link or via redirect)
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // else render form
        render("register_form.php", ["title" => "Register"]);
    }
    
    // else if user reached page via POST (as by submitting a form via POST)
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        //make sure fields are not blank and passwords match
        
       if (empty($_POST["username"])|| empty($_POST["password"]) || empty($_POST["confirmation"]) || $_POST["password"]!= $_POST["confirmation"] )
       
        {
            if (empty($_POST["username"]))
            {
                apologize("Did you forget something? Username can't be blank");
            }
            else if (empty($_POST["password"]))
            {
                apologize("Did you forget something? Password can't be blank");
            }
            else if (empty($_POST["confirmation"]))
            {
                apologize("Did you forget something? Confirmation password can't be blank");
            }
            else if ($_POST["password"] != $_POST["confirmation"])
            {
                apologize("Oops! Password and confirmation password must be the same!");
            }
            
        }
        else 
            {
                
                //if username exists, display error. If not insert user in new row in database and login.
        	if(CS50::query("INSERT INTO users (username, hash) VALUES(?, ?)", $_POST["username"], crypt($_POST["password"])) === false)
        		{
        			apologize("Username already exists");
        		}
        			// insert user in users table
        			$rows = CS50::query("SELECT LAST_INSERT_ID() AS id");
        			$id = $rows[0]["id"];
        			$_SESSION["id"] = $id; 
        			redirect("index.php");
    		    }
	        }
    
else
{
  //show register form again
  render("register_form.php", ["title" => "Register"]);
}
        
     

?>